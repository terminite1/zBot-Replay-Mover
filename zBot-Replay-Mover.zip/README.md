# zBot Replay Mover
the thing lazy people need

# things to follow:

THIS HAS TO BE IN YOUR DOWNLOADS FOLDER
(C:\Users\%USERNAME%\Downloads)
OR ELSE IT WON'T WORK!!!!!!

i also gotta put in CLEAR SIGHT that IT WILL OVERWRITE ANY FILES WITH THE SAME NAME OF THE REPLAY
THAT YOU ARE IMPORTING FROM HERE!
for example, if you have a file named "ag.zbot" in your replays folder; then you import another zbot file
ALSO named "ag" but from here instead, it will automatically overwrite the file that is in the replays folder.
just wanted to make that VERY CLEAR. if you do lose any macro, it is not my fault as this file is here for its
purpose and there might be people who don't care.

ALSO do not change the folder name "zBot Replay Mover" to ANYTHING else or it won't work.

make sure that you have GD installed in its default directory
(C:\Program Files (x86)\Steam\steamapps\common\Geometry Dash) 
if your gd install directory is not default, open the .BAT file in notepad and edit it yourself!

if you don't have a replays folder, why do you not have zbot installed?
this is the entire purpose of the file i made